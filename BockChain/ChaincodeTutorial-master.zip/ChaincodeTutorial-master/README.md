# ChaincodeTutorial
Hyperledger Blockchain Chaincode Java Tutorial

The code in this repository works with Hyperledger Fabric (HLF) v1.0 (eventually)

It is intended to accompany the IBM developerWorks tutorial Chaincode for Java Developers. This tutorial will be updated as soon as possible.

In the meantime, use HLF v0.6, and the v0.6 branch (or tag).

--jsp
